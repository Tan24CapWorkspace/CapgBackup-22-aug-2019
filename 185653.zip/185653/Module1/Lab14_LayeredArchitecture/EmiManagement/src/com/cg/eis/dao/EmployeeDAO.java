package com.cg.eis.dao;

/**
 *
 * @author Tanmay Pathak
 */
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.MismatchException;

import java.util.Collection;

public interface EmployeeDAO {
    public boolean addEmployee(Employee emp);
    public boolean deleteEmployee(Employee emp);
    public boolean updateEmployee(Employee emp);
    public Employee findEmployee(int id);
}
