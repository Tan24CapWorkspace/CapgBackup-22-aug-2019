package com.cg;

public class CurrencyConverterClient {
	public static void main(String[] args) {
		
	}
}	
