package com.cg.test;

import static org.junit.Assume.assumeFalse;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import com.cg.bean.Account;
import com.cg.exception.InsufficientBalanceException;
import com.cg.service.AccountService;
import com.cg.service.Gst;
import org.junit.jupiter.api.DynamicTest;
class ServiceTest {

	static AccountService s;
	Account a;
	
	@BeforeEach
	void beforeEach() {
		s = new AccountService();
		a = new Account(101, 1234567891, "Krish", 10000);
	}
	
	@AfterEach
	void afterEach() {
		s = null;
	}
	
	
	@TestFactory
	Collection<DynamicTest> dynamicTests(){
		return Arrays.asList(
				dynamicTest("First dynamic test", ()->{assertTrue(s.addAccount(a));})
		);
	}
	
	
	@Test
	void addAccountTest() {
		assertTrue(s.addAccount(a));
	}
	
	@Test
	void deleteAccountTest() {
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		assertTrue(s.deleteAccount(a));
	}
	
	@Test
	void findAccountTest() {
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		Account b = s.findAccount(a.getMobile());
		assertEquals(a, b);
	}
	 
	@Test
	void withdrawTest1() throws InsufficientBalanceException {
		double amount = 1000;
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		assertEquals(9000, s.withdraw(a,amount));
	}
	
	
	@Test
	void withdrawTest2() {
		double amount = 10000;
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		Assertions.assertThrows(InsufficientBalanceException.class,()->s.withdraw(a, amount));
	}
	
	@Test
	void depositTest1() {
		double amount = 5000;
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		assertEquals(15000, s.deposit(a, amount));
	}
	
	@Test
	void transferTest1() throws InsufficientBalanceException {
		Account b = new Account(101, 1234567892, "Krish", 20000);
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		s.addAccount(b);
		assumeFalse(s.findAccount(b.getMobile())==null);
		assertTrue(s.transferMoney(a, b, 5000));
		assertEquals(5000, s.findAccount(a.getMobile()).getBalance());
		assertEquals(25000, s.findAccount(b.getMobile()).getBalance());
	}
	
	
	@Test
	void transferTest2() {
		Account b = new Account(101, 1234567892, "Krish", 20000);
		s.addAccount(a);
		assumeFalse(s.findAccount(a.getMobile())==null);
		s.addAccount(b);
		assumeFalse(s.findAccount(b.getMobile())==null);
		assertThrows(InsufficientBalanceException.class, ()->s.transferMoney(a, b, 10000));
	}
	
	@Test
	void calculateTaxTest() {
		assertEquals(12.00, s.calculateTax(Gst.PCT_12, 100));
	}
}
