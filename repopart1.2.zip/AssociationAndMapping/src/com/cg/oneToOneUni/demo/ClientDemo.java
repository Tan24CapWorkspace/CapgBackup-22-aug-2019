package com.cg.oneToOneUni.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ClientDemo {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		
		
		Student s = new Student();
		Address a = new Address();
		s.setName("james");
		a.setCity("gwalir");
		a.setCountry("India");
		s.setAddress(a);
		
		Student s1 = new Student();
		Address a1 = new Address();
		s1.setName("kamal");
		a1.setCity("gwalir");
		a1.setCountry("India");
		s1.setAddress(a1);
		
		em.getTransaction().begin();
		em.persist(s);
		em.persist(s1);
		System.out.println("Record Inserted");
		em.getTransaction().commit();
		
		
		
		
	}
}	
