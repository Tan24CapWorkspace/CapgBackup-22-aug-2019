package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.bean.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao{

	Connection con = DBUtil.getConnection();
	
	@Override
	public Login LoginUser(Login user) {
		String qry = "select * from UserDetails";
		try{
			Statement smt = con.createStatement();
			ResultSet rs = smt.executeQuery(qry);
			while(rs.next()){
				String uName = rs.getString(1);
				String pWd = rs.getString(2);
				System.out.println(uName + pWd);
				System.out.println(user.getUsername()+user.getPassword());
				if(uName.equals(user.getUsername()) && pWd.equals(user.getPassword())){
					System.out.println("get in");
					return user;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}
