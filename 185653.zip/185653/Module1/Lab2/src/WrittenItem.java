
/**
 * @author tanmpath
 */

public abstract class WrittenItem extends Item {
    // Abstract WrittenItem exteds the Item super abstract class
    private String author;

    public WrittenItem(){}

    public WrittenItem(Long UIN, String title, int copies, String author) {
        super(UIN, title, copies);
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
