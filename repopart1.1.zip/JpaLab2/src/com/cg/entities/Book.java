package com.cg.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Book")
@NamedQuery(name = "getall" , query = "Select b from Book b")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer ISBN;
	private String title;
	private Double price;
	
	/**
	 * Book have MANY TO MANY relationship with Author
	 * As a Book can have multiple Authors 
	 * */
	@ManyToMany(targetEntity=Author.class,cascade = {CascadeType.ALL},fetch= FetchType.EAGER)
	 @JoinColumn(name = "ISBN", referencedColumnName = "ISBN")
	private List authors;
	
	
	public Book() {
		// TODO Auto-generated constructor stub
	}


	public Book(Integer iSBN, String title, Double price, List authors) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
		this.authors = authors;
	}


	public Integer getISBN() {
		return ISBN;
	}


	public void setISBN(Integer iSBN) {
		ISBN = iSBN;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public List getAuthors() {
		return authors;
	}


	public void setAuthors(List authors) {
		this.authors = authors;
	}


	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price + ", authors=" + authors + "]";
	}
	
	
}
