package com.cg.eis.service;

/**
 *
 * @author Tanmay Pathak
 */
public interface Validator {
	String eIdPattern = "[1-9]{1}[0-9]{2}";
	String namePattern = "([A-Za-z]){3}([A-Za-z])*( ([A-Za-z]){3}([A-Za-z])*)* "+
						"(([A-Za-z]){3}([A-Za-z])*)|(([A-Za-z]){3}([A-Za-z])* "+
						"(([a-zA-Z])+'([a-zA-Z])+))|(([a-zA-Z])+'([a-zA-Z])+)";
	String balancePattern = "(\\d)+|(\\d)+.(\\d)+";
        String desgPattern = "(system associate|programmer|manager|clerk)";
	
	public static boolean validateData(String data, String pattern) {
		return data.matches(pattern);
	}
}
