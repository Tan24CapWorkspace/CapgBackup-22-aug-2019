package com.cg.eis.service;

public interface Validator {
	static String price_pattern = "[1-9]{1}([0-9])*|[1-9]{1}([0-9])*.([0-9])+|0.([0-9])*[1-9]{1}";
	static String quantity_pattern = "(\\d)+";
	public static boolean validateData(String data, String pattern) {
		return data.matches(pattern);
	}
}
