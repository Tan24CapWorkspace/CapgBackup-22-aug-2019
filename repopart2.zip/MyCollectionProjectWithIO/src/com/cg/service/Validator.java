package com.cg.service;

public interface Validator {
	String aIdPattern = "[1-9]{1}[0-9]{2}";
	String mobilePattern = "[1-9]{1}[0-9]{9}";
	String namePattern = "[A-Z][a-z]{2}([a-z])* [A-Z][a-z]{2}([a-z])*( [A-Z][a-z]{2}([a-z])*)*";
	String balancePattern = "(\\d)+|(\\d)+.(\\d){1-2}";
	
	public static boolean validateData(String data, String pattern) {
		return data.matches(pattern);
	}
}
