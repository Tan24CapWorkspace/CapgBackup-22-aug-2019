package com.cg.eis.service;

import java.util.Collection;

import com.cg.eis.bean.Order;

public interface OrderService {
	final static int INR = 75;
	public int calculateOrder(Order bean);
	public int addOrder(Order bean);
	public Order findOrder(int order_id);
	public boolean removeOrder(Order bean);
	public Collection<Order> getAllOrders();
}
