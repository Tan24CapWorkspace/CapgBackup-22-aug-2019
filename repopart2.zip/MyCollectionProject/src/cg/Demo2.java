package cg;

import java.util.HashSet;
import java.util.Set;

public class Demo2 {
	public static void main(String[] args) {
		/**
		 * This Set is Generic.
		 * And it only accept the String as an element.
		 * */
		Set<String> col = new HashSet<String>();
		col.add("ram");
		col.add("shayam");
		col.add("abdul");
		col.add("55");
		col.add(null);
		col.add("ganesh");
		col.add("ram");
		System.out.println(col);
		/**
		 * Here the ordered is not maintained.
		 * */
	}
}
