package cg;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo1 {

	public static void main(String[] args) throws SQLException{
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			Statement smt = con.createStatement();
			
			ResultSet rs = smt.executeQuery("select * from account");
			
			while(rs.next()) {
				System.out.println("Account no= "+rs.getInt(1) +
						"  Mobile no= "+rs.getLong(2)
						+"  Name= "+rs.getString(3)
						+"  Balance= "+rs.getDouble(4));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			con.close();
		}
	}

}
