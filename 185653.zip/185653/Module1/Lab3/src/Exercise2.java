
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 * @author tanmpath
 */
public class Exercise2 {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter the number of Strings");
            int N = Integer.parseInt(br.readLine());
            String[] strings = new String[N];
            System.out.println("Enter strings:-");
            for (int i = 0; i < N; i++) {
                strings[i] = br.readLine();
            }
            Arrays.sort(strings);
            strings = getElements(strings);
            for (String a : strings) {
                System.out.println(a);
            }
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static String[] getElements(String strings[]) {
        int size = strings.length;
        if ((size % 2) == 0) {
            int a = (int) (size / 2);
            int b = a + 1;
            for (int i = 0; i < a; i++) {
                strings[i] = strings[i].toUpperCase();
            }
            for (int i = a; i < b; i++) {
                strings[i] = strings[i].toLowerCase();
            }
        } else {
            int a = (int) (size / 2) + 1;
            int b = a;
            for (int i = 0; i < a; i++) {
                strings[i] = strings[i].toUpperCase();
            }
            for (int i = a; i < b; i++) {
                strings[i] = strings[i].toLowerCase();
            }
        }
        return strings;
    }
}
