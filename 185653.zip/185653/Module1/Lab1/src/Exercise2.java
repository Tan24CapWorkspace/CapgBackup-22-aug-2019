/**
 *@author tanmpath
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise2 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter a number:");
            int n = Integer.parseInt(br.readLine());
            System.out.println("The required difference is : " + calculateDifference(n));
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static int calculateDifference(int n) {
        double first_sum = 0;
        double second_sum = 0;
        for (int i = 1; i <= n; i++) {
            first_sum += Math.pow(i, 2);
            second_sum += i;
        }
        second_sum = Math.pow(second_sum, 2);
        return (int) (first_sum - second_sum);
    }
}