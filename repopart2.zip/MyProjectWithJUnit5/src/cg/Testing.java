package cg;

public class Testing {
	public static void main(String[] args) throws ClassNotFoundException{
		/**
		 * 3 ways to create the Class object
		 * */
		
		Class c1 = Class.forName("Calculator");
		
		Calculator cal = new Calculator();
		Class c2 = cal.getClass();
		
		Class c3 = Calculator.class;
	}
}
