package com.cg.service;

import com.cg.bean.Login;

public interface LoginService {
	public Login LoginUser(Login user);
}
