import java.util.Collection;
import java.util.Currency;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Test{
	
	public static void main(String[] args) {
		Locale locale= Locale.getDefault();
		Currency cu = Currency.getInstance(locale);
		System.out.println(cu.getCurrencyCode());
		System.out.println(cu.getDisplayName());
		System.out.println(cu.getSymbol());
	}
}
