package com.cg.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise3 {
	interface MyInterface {
		public boolean fun(String x, String y);
	}

	public static void main(String[] args) {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {

			MyInterface ob = (user, pass) -> {
				String username_custom = "Charles";
				String password_custom = "Freedom";

				if (user.equals(username_custom) && pass.equals(password_custom))
					return true;

				return false;
			};

			System.out.println("Enter username :");
			String username = br.readLine();

			System.out.println("Enter password :");
			String password = br.readLine();

			String result = ob.fun(username, password) ? "Correct username & password"
					: "username & password mismathch";

			System.out.println(result);
		} catch (IOException e) {
			System.out.println("Wrong input given");
		}
	}
}
