/**
 * @author tanmpath
 */

public class Book extends WrittenItem {

    public Book(){}

    public Book(long uin, String title, int copies, String author) {
        super(uin, title, copies, author);
    }

    public void print(long uin) {
        Book b = (Book) findItem(uin);
        System.out.println("UIN : " + b.getUin() + " Title : " + b.getTitle() + " Copies : " + b.getCopies() + " Author : " + b.getAuthor());
    }
}
