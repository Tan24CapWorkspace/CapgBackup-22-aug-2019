package com.cg.dao;

/**
 * Author: Tanmay Pathak
 * */
import com.cg.bean.Account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class AccountDAOImpl implements AccountDAO{

	private Map<Long, Account> accList = new HashMap<Long, Account>();
	
	@Override
	public boolean addAccount(Account acc) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			PreparedStatement stm = con.prepareStatement("insert into account values(?,?,?,?)");
			stm.setInt(1, acc.getAid());
			stm.setInt(2, (int)acc.getMobile());
			stm.setString(3, acc.getAccountholder());
			stm.setDouble(4, acc.getBalance());
			return stm.executeUpdate()!=0 ?true:false;
		}catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}finally {
			try {
				con.commit();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public boolean updateAccount(Account acc) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			PreparedStatement stm = con.prepareStatement("update account set balance = ? where mobile =?");
			stm.setDouble(1, acc.getBalance());
			stm.setInt(2, (int)acc.getMobile());
			return stm.executeUpdate()!=0 ?true:false;
		}catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}finally {
			try {
				con.commit();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public boolean deleteAccount(Account acc) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			PreparedStatement stm = con.prepareStatement("delete from account where mobile = ?");
			stm.setInt(1, (int)acc.getMobile());
			return stm.executeUpdate()!=0 ?true:false;
		}catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}finally {
			try {
				con.commit();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public Account findAccount(long mobileNo) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			PreparedStatement stm = con.prepareStatement("select * from account where mobile = ?");
			stm.setInt(1,(int) mobileNo);
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				return new Account(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getDouble(4));
			}else {
				return null;
			}
		}catch (SQLException e) {
			return null;
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public Map<Long, Account> getAccList() {
		Connection con = null;
		Map<Long, Account> list = new HashMap<>();
		try {
			con = DBHelper.getConnection();
			PreparedStatement stm = con.prepareStatement("select * from account");
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				do {
					list.put((long)rs.getInt(2),new Account(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getDouble(4)));
				}while(rs.next());
				return list;
			}else {
				return null;
			}
		}catch (SQLException e) {
			return null;
		}
	}
	
}
