package cg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Demo5 {
	public static void main(String[] args) {
		List<String> col = new ArrayList<String>();
		/**
		 * ArrayList is ordered.
		 * Duplicate are allowed
		 * */
		col.add("ram");
		col.add("shayam");
		col.add("abdul");
		col.add("55");
		col.add(null);
		col.add("ganesh");
		col.add("ram");
		
		System.out.println("Using for each");
		for(String s : col) {
			System.out.println(s);
		}
		
		System.out.println("Using iterator");
		Iterator<String> iterator = col.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}
