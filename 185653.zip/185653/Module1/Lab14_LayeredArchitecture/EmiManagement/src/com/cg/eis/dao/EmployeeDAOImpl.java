package com.cg.eis.dao;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.MismatchException;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Tanmay Pathak
 */
public class EmployeeDAOImpl implements EmployeeDAO{

    Map<Integer, Employee> empList = new HashMap<>();
    
    
    // adding the employee
    @Override
    public boolean addEmployee(Employee emp){
        try{
            empList.put(emp.getId(), emp);
            return true;
        }catch(NullPointerException e){
            return false;
        }
    }

    @Override
    public boolean deleteEmployee(Employee emp) {
        try{
            empList.remove(emp.getId());
            return true;
        }catch(NullPointerException e){
            return false;
        }
    }

    @Override
    public boolean updateEmployee(Employee emp){
        try{
            empList.put(emp.getId(), emp);
            return true;
        }catch(NullPointerException e){
            return false;
        }
    }

    @Override
    public Employee findEmployee(int id) {
        return empList.get(id);
    }
    
}
