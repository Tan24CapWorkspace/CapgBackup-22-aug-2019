package com.cg.exception;

/**
 * Author: Tanmay Pathak
 * */
public class InsufficientFundException extends Exception{
	/**
	 * We extends Exception class to create the custom exception
	 * Here we check for the validity of amount and minimum balance 
	 * to ensure that we maintain the minimum balance 
	 * */
	private double balance;
	
	public InsufficientFundException() {
		// TODO Auto-generated constructor stub
	}
	
	public InsufficientFundException(String message, double balance) {
		/**
		 * Here we pass the message the Exception super class
		 * */
		super(message); 
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "InsufficientFundException: [balance="+balance+"]"+super.getMessage();
	}
}
