package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Calculator {
	public int add(int a,int b) {
		if(a<0 || b<0) return 0;
		return a+b;
	}
	
	public int getId() {
		return (int)Math.random()*1000;
	}
}
