package cg;

import java.util.LinkedHashSet;
import java.util.Set;

public class Demo3 {
	public static void main(String[] args) {
		Set<String> col = new LinkedHashSet<String>();
		col.add("ram");
		col.add("shayam");
		col.add("abdul");
		col.add("55");
		col.add(null);
		col.add("ganesh");
		col.add("ram");
		System.out.println(col);
		/**
		 * Here the ordered of the element is maintained.
		 * */
	}
}
