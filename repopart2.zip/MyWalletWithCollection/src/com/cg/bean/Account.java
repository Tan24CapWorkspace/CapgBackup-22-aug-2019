package com.cg.bean;

/**
 * Author: Tanmay Pathak
 * */
public class Account {
	
	private int aid;
	private long mobile;
	private String accountholder;
	private double balance;
	
	public Account() { 
	}
	public Account(int aid, long mobile2, String accountholder, double balance) {
		super();
		this.aid = aid;
		this.mobile = mobile2;
		this.accountholder = accountholder;
		this.balance = balance;
	}
	
	
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getAccountholder() {
		return accountholder;
	}
	public void setAccountholder(String accountholder) {
		this.accountholder = accountholder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	@Override
	public String toString() {
		return "Account [aid=" + aid + ", mobile=" + mobile + ", accountholder=" + accountholder + ", balance="
				+ balance + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountholder == null) ? 0 : accountholder.hashCode());
		result = prime * result + aid;
		long temp;
		temp = Double.doubleToLongBits(balance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (mobile ^ (mobile >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountholder == null) {
			if (other.accountholder != null)
				return false;
		} else if (!accountholder.equals(other.accountholder))
			return false;
		if (aid != other.aid)
			return false;
		if (Double.doubleToLongBits(balance) != Double.doubleToLongBits(other.balance))
			return false;
		if (mobile != other.mobile)
			return false;
		return true;
	}
	
	
}