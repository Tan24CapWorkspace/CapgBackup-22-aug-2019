
import java.util.HashMap;
import java.util.Map;

/**
 * @author tanmpath
 */
public abstract class Item {
    // Abstract Item class 
 
    Long uin;   // unique identification number
    String title;   // title of the item
    int copies = 0;    // maintain the count of the item

    static Map<Long, Item> m = new HashMap<>();

    public Item() {
    }

    public Item(Long uin, String title, int copies) {
        super();
        this.uin = uin;
        this.title = title;
        this.copies = copies;
    }

    public Long getUin() {
        return uin;
    }

    public void setUin(Long uin) {
        this.uin = uin;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCopies() {
        return copies;
    }

    public void setCopies(int copies) {
        this.copies = copies;
    }

    @Override
    public String toString() {
        return "Item [UIN=" + uin + ", title=" + title + ", copies=" + copies + "]";
    }

    //Abstract function
    public abstract void print(long uin);

    public static void printAll() {
        System.out.println(m);
    }

    public Item findItem(long uin) {
        return m.get(uin);
    }

    public void addItem(Item i) {
        m.put(i.getUin(), i);
    }

    public void checkIn(long uin) {
        Item i = findItem(uin);
        i.setCopies(i.getCopies() + 1);
    }

    public void checkOut(long uin) {
        Item i = findItem(uin);
        i.setCopies(i.getCopies() - 1);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((uin == null) ? 0 : uin.hashCode());
        result = prime * result + copies;
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Item other = (Item) obj;
        if (uin == null) {
            if (other.uin != null) {
                return false;
            }
        } else if (!uin.equals(other.uin)) {
            return false;
        }
        if (copies != other.copies) {
            return false;
        }
        if (title == null) {
            if (other.title != null) {
                return false;
            }
        } else if (!title.equals(other.title)) {
            return false;
        }
        return true;
    }
}
