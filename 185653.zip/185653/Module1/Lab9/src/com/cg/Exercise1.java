package com.cg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tanmpath
 */
public class Exercise1 {
	public static void main(String args[]) throws IOException {
		Map<String, Integer> map = new HashMap<String, Integer>();
		ArrayList<Integer> list = new ArrayList<Integer>(map.values());
		list = getValues(map);

		for (Integer o : list) {
			System.out.println(o);
		}
	}

	public static ArrayList<Integer> getValues(Map<String, Integer> map) {
		map.put("A", 5);
		map.put("B", 9);
		map.put("C", 1);
		ArrayList<Integer> list = new ArrayList<Integer>(map.values());
		Collections.sort(list);
		return list;
	}

}
