package cg;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface PrintAccount {
	public static void print(ResultSet rs) {
		try{if(rs.next()) {
			do {
					System.out.println("Account no= "+rs.getInt(1) +
							"  Mobile no= "+rs.getLong(2)
							+"  Name= "+rs.getString(3)
							+"  Balance= "+rs.getDouble(4));
				
			}while(rs.next());
		}else {
			System.out.println("No record found");
		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
	}
}
