package cg;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo3 {
	public static void main(String[] args) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			
			Statement smt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = smt.executeQuery("select aid, mobileno, accountholder, balance from account");
			
			while(rs.next()) {
				if(rs.getInt(1) == 101) {
					rs.updateString(3, "Raja Sharma");
					rs.updateDouble("balance", 100000);
					rs.updateRow();
				}
				System.out.println("Account no= "+rs.getInt(1) +
						"  Mobile no= "+rs.getLong(2)
						+"  Name= "+rs.getString(3)
						+"  Balance= "+rs.getDouble(4));
				
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
