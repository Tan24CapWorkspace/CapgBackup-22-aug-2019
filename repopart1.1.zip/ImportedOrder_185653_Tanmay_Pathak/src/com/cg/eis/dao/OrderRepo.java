package com.cg.eis.dao;

import java.util.Collection;

import com.cg.eis.bean.Order;

public interface OrderRepo {
	public int saveOrder(Order bean);
	public Order findOrder(int order_id);
	public boolean removeOrder(Order bean);
	public Collection<Order> getAllOrders();
}
