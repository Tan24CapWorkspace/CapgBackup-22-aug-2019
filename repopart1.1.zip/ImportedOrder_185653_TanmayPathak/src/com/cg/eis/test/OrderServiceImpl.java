package com.cg.eis.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.eis.bean.Order;

class OrderServiceImpl { 
	@BeforeEach
	void setup() {
		OrderServiceImpl service = new OrderServiceImpl();
	}
	
	@Test
	void calculateOrderTest() {
		Order order = new Order(100, 25, 5, 9375,)
	}

}
