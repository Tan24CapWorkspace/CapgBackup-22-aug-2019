package com.cg.service;
/**
 * @author tanmpath
 * */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise2 {
	interface MyInterface {
		public String fun(String input);
	}

	public static void main(String[] args) {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {

			MyInterface ob = (x) -> x.replaceAll("", " ").replaceAll(" +", " ").trim();

			System.out.println("Enter the input string");

			String input = br.readLine();

			System.out.println("Result is : \n");
			System.out.println(ob.fun(input));

		} catch (IOException e) {
			System.out.println("Wrong input given");
		}
	}
}
