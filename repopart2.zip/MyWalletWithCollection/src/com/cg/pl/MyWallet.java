package com.cg.pl;


/**
 * Author: Tanmay Pathak
 * */

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;
import com.cg.service.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MyWallet {
	public static void main(String[] args) throws IOException {

		// creating account service
		AccountService service = new AccountService();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		// providing options
		while (true) {
			System.out.println("=========================MENU=====================");
			System.out.println("1. Create New Account");
			System.out.println("2. Update Existing Account");
			System.out.println("3. Delete Account");
			System.out.println("4. Find Account");
			System.out.println("5. Display Accounts");
			System.out.println("6. EXIT");

			// take the choice
			String choice = br.readLine();

			switch (choice) {

			case "1": // creating account
				int id = 0;
				long mobile = 0L;
				String holder = null;
				double balance = 0.0;

				// adding mobile
				System.out.println("Enter Mobile no.");
				while (true) {
					String s_m = br.readLine();
					if (Validator.validateData(s_m, Validator.mobilePattern)) {
						try {
							mobile = Long.parseLong(s_m);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Invalid Mobile no");
							System.out.println("Re-Enter the Mobile no.");
						}
					} else {
						System.out.println("Invalid Mobile no");
						System.out.println("Re-Enter the Mobile no.");
					}
				}
				Account acc = null;
				if (service.findAccount(mobile) == null) {

					// adding account no
					System.out.println("Enter Account No.");
					while (true) {
						String s_id = br.readLine();
						if (Validator.validateData(s_id, Validator.aIdPattern)) {
							try {
								id = Integer.parseInt(s_id);
								break;
							} catch (NumberFormatException e) {
								System.out.println("ID should be numeric.");
							}
						} else {
							System.out.println("Invalid ID.");
						}
					}

					// account holder name
					System.out.println("Enter Holder name");
					while (true) {
						String s_name = br.readLine();
						if (Validator.validateData(s_name, Validator.namePattern)) {
							try {
								holder = s_name;
								break;
							} catch (NumberFormatException e) {
								System.out.println("Invalid Name");
								System.out.println("Re-Enter the Name.");
							}
						} else {
							System.out.println("Invalid Name");
							System.out.println("Re-Enter the Name.");
						}
					}

					// account balance
					System.out.println("Enter Account balance");
					while (true) {
						String s_bal = br.readLine();
						if (Validator.validateData(s_bal, Validator.balancePattern)) {
							try {
								balance = Double.parseDouble(s_bal);
								break;
							} catch (NumberFormatException e) {
								System.out.println("Invalid Balance");
								System.out.println("Re-Enter the Balance");
							}
						} else {
							System.out.println("Invalid Balance");
							System.out.println("Re-Enter the Balance");
						}
					}

					acc = new Account(id, mobile, holder, balance);
					if (service.addAccount(acc)) {
						System.out.println("Account Added");
					} else {
						System.out.println("Account Not Added");
					}
				} else {
					System.out.println("Account Already Exist");
				}

				break;

			// ----------------------------------------------------------------------------------------------------------------
			case "2": // update
				System.out.println("Enter Mobile No."); {

				while (true) {
					String s_m = br.readLine();
					if (Validator.validateData(s_m, Validator.mobilePattern)) {
						try {
							mobile = Long.parseLong(s_m);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Invalid Mobile no");
							System.out.println("Re-Enter the Mobile no.");
						}
					} else {
						System.out.println("Invalid Mobile no");
						System.out.println("Re-Enter the Mobile no.");
					}
				}

				acc = service.findAccount(mobile);
				if (acc != null) {
					choice = "0";

					System.out.println("1. Withdraw amount");
					System.out.println("2. Deposit money");
					System.out.println("3. Transfer Money");

					System.out.println("Enter choice");
					choice = br.readLine();

					switch (choice) {
					case "1": // withdraw
						try {
							System.out.println("Enter the amount");
							service.withdraw(acc, Double.parseDouble(br.readLine()));
							System.out.println("Transaction completed");
						} catch (InsufficientFundException e) {
							System.out.println(e.getMessage());
						}
						break;
					case "2": // deposit
						System.out.println("Enter the amount");
						try {
							service.deposit(acc, Double.parseDouble(br.readLine()));
							System.out.println("Transaction completed");
						} catch (InsufficientFundException e) {
							System.out.println(e.getMessage());
						}
						break;
					case "3": // transfer money
						Account from = acc;
						Account to = null;

						System.out.println("Enter Mobile no. of account where money to transfer");
						while(true) {
							mobile = getMobile();
							acc = service.findAccount(mobile);
							if (acc != null) {
								to = acc;
								break;
							} else {
								System.out.println("Account not found\nRe-Enter mobile no.");
							}
						}
					
						System.out.println("Enter Amount");
						try {
							service.transferMoney(from, to, Double.parseDouble(br.readLine()));
							System.out.println("Amount Transferred");
						} catch (InsufficientFundException e) {
							System.out.println(e.getMessage());
						}

						break;
					default:
						System.out.println("Invalid choice");
					}

				} else {
					System.out.println("Account Not found");
				}

			}

				break;

			// ----------------------------------------------------------------------------------------------------------------
			case "3": // delete
				System.out.println("Enter Mobile No."); {
				String s_mobile = br.readLine();
				if (Validator.validateData(s_mobile, Validator.mobilePattern)) {
					acc = service.findAccount(Long.parseLong(s_mobile));
					if (acc != null) {
						service.deleteAccount(acc);
						System.out.println("Account Deleted");
					} else {
						System.out.println("Account not found");
					}
				} else {
					System.out.println("Invalid Mobile no.");
				}
			}
				break;

			// ----------------------------------------------------------------------------------------------------------------
			case "4": // find
				System.out.println("Enter Mobile no."); {
				String s_mobile = br.readLine();
				if (Validator.validateData(s_mobile, Validator.mobilePattern)) {
					acc = service.findAccount(Long.parseLong(s_mobile));
					if (acc != null) {
						System.out.println("Account found.");
						service.printStatement(acc);
					} else {
						System.out.println("Account not found");
					}
				} else {
					System.out.println("Invalid Mobile no.");
				}
			}
				break;

			// ----------------------------------------------------------------------------------------------------------------
			case "5": // display
				System.out.println("Current Account present");
				List<Account> list = new ArrayList(service.getAllAccount().values());
				for (Account a : list) {
					service.printStatement(a);
					System.out.println();
				}
				break;
			case "6":
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
			}
			System.out.println("\n\n");
		}
	}

	// to get mobile no from user
	private static Long getMobile() throws IOException {
		long mobile;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Mobile no.");
		while (true) {
			String s_m = br.readLine();
			if (Validator.validateData(s_m, Validator.mobilePattern)) {
				try {
					mobile = Long.parseLong(s_m);
					return mobile;
				} catch (NumberFormatException e) {
					System.out.println("Invalid Mobile no");
					System.out.println("Re-Enter the Mobile no.");
				}
			} else {
				System.out.println("Invalid Mobile no");
				System.out.println("Re-Enter the Mobile no.");
			}
		}
	}
}