package cg;

public class Validator {
	public boolean validator(String data) {
		return data.matches("\\d+");
	}
}
