package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	static Connection con;
	static{
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user= "hr";
			String pass = "hr"; 
			
			con = DriverManager.getConnection(url,user,pass);
			System.out.println("Got connection");
		} catch (Exception e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection(){
		return con;
	}
}
