package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo4 {
	public static void main(String[] args) {
		Connection con = null;
		try {
			con = DBHelper.getConnection();
			
			// setting auto commit false
			con.setAutoCommit(false);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Enter account id");
			int id = Integer.parseInt(br.readLine());
			
			System.out.println("Enter mobile no");
			long mobile = Long.parseLong(br.readLine());
			
			System.out.println("Enter initial balance");
			double balance = Double.parseDouble(br.readLine());
			 
			System.out.println("Enter account holder name");
			String name = br.readLine();
			
			String query = "insert into account values(?,?,?,?)"; 
			
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setInt(1, id);
			pstm.setLong(2, mobile);
			pstm.setString(3, name);
			pstm.setDouble(4, balance);
			
			int insertedRec = pstm.executeUpdate();
			
			System.out.println("Inserted Record : "+insertedRec);
			
			con.commit();
			con.close();
			
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
