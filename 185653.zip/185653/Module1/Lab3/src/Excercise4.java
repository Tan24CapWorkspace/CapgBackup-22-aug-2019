
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author tanmpath
 */
public class Excercise4 {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter number of characters : (without enter and space)");
            // e.g adlkjlk --> like this
            
            int N = Integer.parseInt(br.readLine());
            char[] elements = new char[N];
            for (int i = 0; i < elements.length; i++) {
                elements[i] = (char) br.read();
                System.out.println("james");
            }
            countChar(elements);
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static void countChar(char c[]) {
        Map<Character, Integer> m = new TreeMap<>();
        int i = 0;
        while (i < c.length) {
            if (m.containsKey(c[i])) {
                m.put(c[i], m.get(c[i]) + 1);
            } else {
                m.put(c[i], 1);
            }
            i++;
        }

        for (Map.Entry<Character, Integer> e : m.entrySet()) {
            System.out.println("Character:" + e.getKey() + " No of times it appeared:" + e.getValue());
        }
    }
}
