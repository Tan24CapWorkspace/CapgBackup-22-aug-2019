package com.cg.dao;

import java.util.List;

import com.cg.entities.Author;
import com.cg.entities.Book;

public interface BookAuthor {
	public List<Book> getAllBooks();
	public List<Book> getBooksByAuthorName(Author author);
	public List<Book> getBooksBwRange(int min,int max);
}
