package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.MismatchException;

/**
 *
 * @author Tanmay Pathak
 */
public interface EmpServiceInterface {
	
    public boolean addEmployee(Employee emp) throws MismatchException;
    public boolean deleteEmployee(Employee emp);
    public boolean updateEmployee(Employee emp) throws MismatchException;
    public Employee findEmployee(int id);
    
    public default void printEmpDetails(Employee emp) {
    	System.out.println("Emp ID: "+emp.getId()+"\nEmp Name: "+emp.getName()
    	+"\nEmp Designation: "+emp.getDesg()+"\nEmp salary: "+emp.getSalary()
    	+"\nEmp Scheme: "+emp.getScheme());
    }
}
