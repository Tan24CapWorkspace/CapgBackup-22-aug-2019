package cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	static Calculator c;
	
	@BeforeAll
	public static void beforeAll() {
		System.out.println("before all");
		c = new Calculator();
	}
	@AfterAll
	public static void AfterAll() {
		System.out.println("after all");
		c = null;
	}
	
	
//	@BeforeEach
//	public void beforeEachTest(){
//		System.out.println("Before each test");
//		c = new Calculator();
//	}
//	
//	@AfterEach
//	public void afterEachTest() {
//		System.out.println("After each");
//		c = null;
//	}
	
	
	
	@Test
	void testadd() {
		System.out.println("test case testadd");
		assertEquals(9, c.add(4, 5));
	}

	@Test
	void testadd1() {
		System.out.println("test case testadd1");
		assertTrue(c.add(4, 5) >= 0);
		assertTrue(c.add(-5, 5) >=0);
	}
	
	
	@RepeatedTest(5)
	//@Test
	void testing() {
			int temp = c.getId();
			System.out.println(temp);
			assertTrue(temp<=1000 && temp>=0);
	}
}
