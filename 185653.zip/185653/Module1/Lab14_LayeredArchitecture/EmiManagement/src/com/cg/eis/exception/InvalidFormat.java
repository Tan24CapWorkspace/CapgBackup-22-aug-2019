package com.cg.eis.exception;

/**
 *
 * @author Tanmay Pathak
 */
public class InvalidFormat extends Exception{
    public InvalidFormat(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
    
}
