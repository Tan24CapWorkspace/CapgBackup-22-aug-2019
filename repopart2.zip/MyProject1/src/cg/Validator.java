package cg;

public class Validator {
	public boolean validateNo(String data) {
		return data.matches("\\d+");
	}
	
	public boolean isPalindrome(String data) {
		StringBuffer bu = new StringBuffer(data);
		String result = bu.reverse().toString();
		return data.equals(result);
	}
	
	public int getSizeinMi(Size size) {
		return size.getMl();
	}
}
