package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class ValidatorTest {

	@ParameterizedTest
	@ValueSource(strings = {"racecar","radar","nitin","naman"})
	void test(String data) {
		Validator ob = new Validator();
		System.out.println("test is palindrome with value"+data);
		assertTrue(ob.isPalindrome(data));
	}
	
	@ParameterizedTest
	@CsvSource({"4,5","10,20","100,500"})
	void test4(int a,int b) {
	
	}

}
