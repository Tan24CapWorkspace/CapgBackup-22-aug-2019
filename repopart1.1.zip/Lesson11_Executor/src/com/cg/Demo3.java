package com.cg;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Demo3 {
	public static void main(String[] args) {
		Runnable task = ()->{
			System.out.println("Thread 1 is running");
			try {
				Thread.sleep(10000);
				System.out.println("Thread 1 exit");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		Runnable task2 = ()->{
			System.out.println("Thread 2 is running");
			try {
				Thread.sleep(11000);
				System.out.println("Thread 2 exit");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		Runnable task3 = ()->{
			System.out.println("Thread 3 is running");
			try {
				Thread.sleep(10000);
				System.out.println("Thread 3 exit");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		//ExecutorService executor = Executors.newSingleThreadExecutor();
		ExecutorService executor = Executors.newFixedThreadPool(2);
		executor.execute(task);
		executor.execute(task2);
		executor.execute(task3);
		executor.shutdown();
	}
}
