package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import com.cg.bean.*;
import com.cg.service.*;

public class AccountCollection {
	public static void main(String[] args) throws IOException{
		Map<Long, Account> accMap = new TreeMap<Long, Account>();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			System.out.println("===========MENU============");
			System.out.println("1. Create new account");
			System.out.println("2. Print all account");
			System.out.println("3. Exit");
			System.out.println("\nEnter your choice\n");
			
			String choice = br.readLine();
			
			switch(choice) {
				case "1": // create the account
					int id =0;
					long mb = 0L;
					String ah = null;
					double balance = 0.0;
					
					/*
					 * Taking and validating the input
					 * */
					
					// get the account no from user and validate it
					System.out.println("Enter the Account No.");
					while(true) {
						String s_id = br.readLine();
						if(Validator.validateData(s_id, Validator.aIdPattern)) {
							try {
								id = Integer.parseInt(s_id);
								break;
							}catch(NumberFormatException e) {
								System.out.println("Account Number must be numeric.");
							}
						}else {
							System.out.println("The Account No. is Invalid: Re-Enter the Account No. 3 digits");
						}
					}
					
					// Taking the mobile No. and validating it.
					System.out.println("Enter Mobile No.");
					while(true) {
						String s_mb = br.readLine();
						if(Validator.validateData(s_mb, Validator.mobilePattern)) {
							try {
								mb = Long.parseLong(s_mb);
								break;
							}catch(NumberFormatException e) {
								System.out.println("The given Mobile No. in invalid.");
							}
						}else {
							System.out.println("The given Mobile No. in invalid.");
						}
					}
					
					
					// Taking and validating name.
					System.out.println("Enter Account Holder Name");
					while(true) {
						String s_name = br.readLine();
						if(Validator.validateData(s_name, Validator.namePattern)) {
							ah = s_name;
							break;
						}else {
							System.out.println("Enter a valid Name: \n\tIt sould be in the format: Firstname Lastname | Firstname Middlename Lastname");
						}
					}
					
					
					// Taking and validating balance.
					System.out.println("Enter Initial Balance");
					balance  = Double.parseDouble(br.readLine());
					
					Account acc = new Account(id, mb, ah, balance);
					accMap.put(mb, acc);
					System.out.println("Account Created");
					
					break;
				case "2": // print all the account details
					System.out.println("Account Present");
					printList(accMap.values());
					break;
				case "3":
					System.exit(0);
					break;
				default:
					System.out.println("Invalid choice given");
			}
		}
		
		
		
		
		
//		System.out.println(accMap.keySet());
//		System.out.println("==========================================\n");
//		
//		// get the account list
//		List<Account> accountList = getAccounts(accMap);
//		
//		// sorting the list using the buildin compareTo function of the Account class
//		Collections.sort(accountList);
//		System.out.println("Sorting using account id:");
//		printList(accountList);
//		System.out.println("==========================================\n");
//		
//		// Custom sorting using comparator class
//		Collections.sort(accountList, new Comparator<Account>() {
//			@Override
//			public int compare(Account arg0, Account arg1) {
//				return arg0.getAccountholder().compareTo(arg1.getAccountholder());
//			}
//		});
//		System.out.println("Sorting using account holder name:");
//		printList(accountList);
//		System.out.println("==========================================\n");
//		
//		// Custom Comparator
//		Comparator nc = new NameComparator();
//		Collections.sort(accountList, nc);
//		System.out.println("Sorted by Name");
//		printList(accountList);
//		System.out.println("==========================================\n");
//		
//		
//		Comparator bc = new BalanceComparator();
//		Collections.sort(accountList, bc);
//		System.out.println("Sorted by Balance");
//		printList(accountList);
//		System.out.println("==========================================\n");
//		
//		// since set need the comparison while insertion
//		// we need to implement compareTo for that
//		Set<Account> aset = new TreeSet<>();
//		aset.addAll(accountList); // compareTo method of Account Comparable 
//								  // default sorting
//		System.out.println("Set of account sorted by default compareTo");
//		printList(aset);
//		System.out.println("==========================================\n");
//		
//		// sort by name
//		aset = new TreeSet<>(nc);
//		// here compare function of NameComparator is called to compare 
//		// the objects of the Account
//		aset.addAll(accountList);
//		System.out.println("Set of account sorted by NameComparator");
//		printList(aset);
//		System.out.println("==========================================\n");
//		
	}
	
	public static ArrayList<Account> getAccounts(Map<Long, Account> list){
		return new ArrayList<Account>(list.values());
	}
	
	public static void printList(Collection list) {
		for(Object o : list) {
			System.out.println(o);
		}
	}
}
