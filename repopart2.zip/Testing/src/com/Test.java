package com;

public class Test {
	enum Color{RED, GREEN, BLUE};
	public static void main(String[] args) {
		Color c = Color.BLUE;
		System.out.println(c);
	}
}
