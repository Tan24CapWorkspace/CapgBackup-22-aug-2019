
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 * @author tanmpath
 */
public class Exercise1 {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter the size of the array");
            int N = Integer.parseInt(br.readLine());

            int[] array = new int[N];

            System.out.println("Enter the elements");
            for (int i = 0; i < N; i++) {
                array[i] = Integer.parseInt(br.readLine());
            }
            
            System.out.println("The second largest element is : " + getSecondSmallest(array));
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static int getSecondSmallest(int a[]) {
        Arrays.sort(a);
        int b = a[a.length - 2];
        return b;
    }
}
