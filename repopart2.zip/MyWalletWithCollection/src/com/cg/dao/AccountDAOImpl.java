package com.cg.dao;

/**
 * Author: Tanmay Pathak
 * */
import com.cg.bean.Account;

import java.util.HashMap;
import java.util.Map;

public class AccountDAOImpl implements AccountDAO{

	private Map<Long, Account> accList = new HashMap<Long, Account>();
	
	@Override
	public boolean addAccount(Account acc) {
		try {
			accList.put(acc.getMobile(), acc);
			return true;
		}catch(NullPointerException e) {
			return false;
		}
	}

	@Override
	public boolean updateAccount(Account acc) {
		try {
			accList.put(acc.getMobile(), acc);
			return true;
		}catch(NullPointerException e) {
			return false;
		}
	}

	@Override
	public boolean deleteAccount(Account acc) {
		try {
			accList.remove(acc);
			return true;
		}catch(NullPointerException e) {
			return false;
		}
	}

	@Override
	public Account findAccount(long mobileNo) {
		return accList.get(mobileNo);
	}
	
	public Map<Long, Account> getAccList() {
		return accList;
	}
	
}
