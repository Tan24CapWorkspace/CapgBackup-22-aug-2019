
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author tanmpath
 */
public class Exercise3 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter the size of the array");
            int N = Integer.parseInt(br.readLine());
            int[] array = new int[N];
            System.out.println("Enter elements");
            for (int i = 0; i < N; i++) {
                array[i] = Integer.parseInt(br.readLine());
            }
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static int[] reversingArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            StringBuffer buffer = new StringBuffer(String.valueOf(array[i]));
            buffer.reverse();
            array[i] = Integer.parseInt(buffer.toString());
        }
        return array;
    }
}
