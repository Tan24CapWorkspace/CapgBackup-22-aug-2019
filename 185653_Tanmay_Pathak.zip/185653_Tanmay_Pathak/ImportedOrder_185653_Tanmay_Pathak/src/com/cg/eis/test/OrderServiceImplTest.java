package com.cg.eis.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.eis.bean.Order;
import com.cg.eis.service.OrderServiceImpl;

class OrderServiceImplTest { 
	OrderServiceImpl service= new OrderServiceImpl();
	
	@Test
	void calculateOrderTest() {
		Order order = new Order(100, 25, 5, 9375,117.1875);
		assertEquals(1875, service.calculateOrder(order));
	}
	
	@Test
	void addOrderTest() {
		Order order = new Order(100, 25, 5, 9375,117.1875);
		assertEquals(100, service.addOrder(order));
	}
	
	@Test
	void findOrderTest() {
		Order order = new Order(100, 25, 5, 9375,117.1875);
		service.addOrder(order);
		assertEquals(order, service.findOrder(order.getId()));
	}
	
	@Test
	void removeOrderTest() {
		Order order = new Order(100, 25, 5, 9375,117.1875);
		service.addOrder(order);
		assertTrue(service.removeOrder(order));
	}
}
