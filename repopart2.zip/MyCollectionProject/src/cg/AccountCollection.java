package cg;

import java.util.*;
import com.cg.bean.*;

public class AccountCollection {
	public static void main(String[] args) {
		Map<Integer, Account> accMap = new TreeMap<Integer, Account>();

		Account ob1 = new Account(101, 64654654, "Ram", 25000.00);
		Account ob2 = new Account(102, 23423423, "Kishan", 24000.00);
		Account ob3 = new Account(103, 23453455, "Ravi", 21000.00);
		Account ob4 = new Account(104, 54674567, "Pravek", 22000.00);

		accMap.put(ob1.getMobile(), ob1);
		accMap.put(ob2.getMobile(), ob2);
		accMap.put(ob3.getMobile(), ob3);
		accMap.put(ob4.getMobile(), ob4);
		
		System.out.println(accMap.keySet());
		System.out.println("==========================================\n");
		
		// get the account list
		List<Account> accountList = getAccounts(accMap);
		
		
		// sorting the list using the buildin compareTo function of the Account class
		Collections.sort(accountList);
		System.out.println("Sorting using account id:");
		printList(accountList);
		System.out.println("==========================================\n");
		
		
		
		
		// Custom sorting using comparator class
		Collections.sort(accountList, new Comparator<Account>() {
			@Override
			public int compare(Account arg0, Account arg1) {
				return arg0.getAccountholder().compareTo(arg1.getAccountholder());
			}
		});
		System.out.println("Sorting using account holder name:(using anonymous class)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		// using lambda
		Collections.sort(accountList, (a1, a2)-> a1.getAccountholder().compareTo(a2.getAccountholder()));
		System.out.println("Sorting using account holder name: (using lambda)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		
		
		
		
		
		// Custom Comparator
		Comparator nc = new NameComparator();
		Collections.sort(accountList, nc);
		System.out.println("Sorted by Name (using class implements comparator)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		// using lambda
		Collections.sort(accountList, (a1,a2)->a1.getAccountholder().compareTo(a2.getAccountholder()));
		System.out.println("Sorted by Name (using lambda)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		
		
		
		// Custom comparator BalanceComparator
		Comparator bc = new BalanceComparator();
		Collections.sort(accountList, bc);
		System.out.println("Sorted by Balance (using custom compatator BalanceComparator)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		// using lambda
		Collections.sort(accountList, (a1,a2)->(int)Math.round(a1.getBalance() - a2.getBalance()));
		System.out.println("Sorted by Balance (using lambda expression)");
		printList(accountList);
		System.out.println("==========================================\n");
		
		
		
		
		
		// since set need the comparison while insertion
		// we need to implement compareTo for that
		Set<Account> aset = new TreeSet<>();
		aset.addAll(accountList); // compareTo method of Account Comparable 
								  // default sorting
		System.out.println("Set of account sorted by default compareTo");
		printList(aset);
		System.out.println("==========================================\n");
		
		// sort by name
		aset = new TreeSet<>(nc);
		// here compare function of NameComparator is called to compare 
		// the objects of the Account
		aset.addAll(accountList);
		System.out.println("Set of account sorted by NameComparator");
		printList(aset);
		System.out.println("==========================================\n");
		
	}
	
	public static ArrayList<Account> getAccounts(Map<Integer, Account> list){
		return new ArrayList<Account>(list.values());
	}
	
	public static void printList(Collection list) {
		for(Object o : list) {
			System.out.println(o);
		}
	}
}
