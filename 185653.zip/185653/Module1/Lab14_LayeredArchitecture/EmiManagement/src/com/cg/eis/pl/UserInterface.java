package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.InvalidFormat;
import com.cg.eis.exception.MismatchException;
import com.cg.eis.service.EmpService;
import com.cg.eis.service.Validator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Tanmay Pathak
 */
public class UserInterface {

	public static void main(String[] args) {
		System.out.println("Welcome");

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		EmpService service = new EmpService();
		while (true) {
			System.out.println("\n\n================ Menu ==================");
			System.out.println("1. Add new Employee");
			System.out.println("2. Delete Employee");
			System.out.println("3. Update Employee");
			System.out.println("4. Find Employee");
			// System.out.println("5. Get All Employee");
			System.out.println("5. EXIT");
			System.out.println("Enter your choice\n");

			try {
				String choice = br.readLine();

				switch (choice) {
				case "1": // add emp
					Employee emp;
					while (true) {
						try {
							System.out.println("Enter information of New Employee\n");
							emp = generateEmployee();
							service.addEmployee(emp);
							System.out.println("Employee with ID: " + emp.getId() + " added successfully.");
							break;
						} catch (MismatchException e) {
							System.out.println(e.getMessage());
						}
					}

					break;
				case "2": // delete emp
					int id = generateEid();
					emp = service.findEmployee(id);
					if (emp != null) {
						service.deleteEmployee(emp);
						System.out.println("Emp with ID: " + id + " deleted");
					} else {
						System.out.println("No Emp with ID : " + id + " found");
					}
					break;
				case "3": // update emp
					id = generateEid();
					emp = service.findEmployee(id);
					if (emp != null) {
						updateEmployee(emp, service);
					} else {
						System.out.println("No Emp with ID : " + id + " found");
					}
					break;
				case "4": // find emp
					id = generateEid();
					emp = service.findEmployee(id);
					if (emp != null) {
						System.out.println("Employee found:--");
						service.printEmpDetails(emp);
					} else {
						System.out.println("No Emp with ID : " + id + " found");
					}
					break;
				case "5":
					System.exit(0);
					break;
				default:
					System.out.println("Invalid choice");
				}
			} catch (IOException e) {
				System.out.println("Wrong input given");
			}
		}
	}

	// generating account
	private static Employee generateEmployee() {
		int id;
		String name;
		double salary;
		String desg;

		try {
			id = generateEid();
			name = generateEName();
			salary = generateSalary();
			desg = generateDesg();

			Employee emp = new Employee(id, name, salary, desg);

			return emp;
		} catch (IOException e) {
			System.out.println("Invalid Input format");
		}

		return null;
	}

	// to get id from user
	private static int generateEid() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emp id (1. Must be of 3 numbers\t2. Does not start with 0.)");
		while (true) {
			String s_id = br.readLine();
			try {
				if (Validator.validateData(s_id, Validator.eIdPattern)) {
					try {
						return Integer.parseInt(s_id);
					} catch (NumberFormatException e) {
						throw new InvalidFormat("Invalid ID format\nRe-Enter the ID");
					}
				} else {
					throw new InvalidFormat("Invalid ID format\nRe-Enter the ID");
				}
			} catch (InvalidFormat e) {
				System.out.println(e.getMessage());
			}
		}
	}

	// to get name from user
	private static String generateEName() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emp Name");
		while (true) {
			String s_name = br.readLine();
			try {
				if (Validator.validateData(s_name, Validator.namePattern)) {
					return s_name.replaceAll(" +", " ").trim();
				} else {
					throw new InvalidFormat("Invalid Name format\nRe-Enter the Emp Name");
				}
			} catch (InvalidFormat e) {
				System.out.println(e.getMessage());
			}
		}
	}

	// to get salary from user
	private static double generateSalary() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emp Salary");
		while (true) {
			String s_sal = br.readLine();
			try {
				if (Validator.validateData(s_sal, Validator.balancePattern)) {
					try {
						return Double.parseDouble(s_sal);
					} catch (NumberFormatException e) {
						throw new InvalidFormat("Invalid Number format\nRe-Enter the Emp Salary");
					}
				} else {
					throw new InvalidFormat("Invalid Number format\nRe-Enter the Emp Salary");
				}
			} catch (InvalidFormat e) {
				System.out.println(e.getMessage());
			}
		}
	}

	// to get designation from user
	private static String generateDesg() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emp Designation");
		while (true) {
			String s_desg = br.readLine().replaceAll(" +", " ").trim().toLowerCase();
			try {
				if (Validator.validateData(s_desg.toLowerCase(), Validator.desgPattern)) {
					return s_desg;
				} else {
					throw new InvalidFormat("Invalid Designation\nRe-Enter the designation");
				}
			} catch (InvalidFormat e) {
				System.out.println(e.getMessage());
			}
		}
	}

	// update
	private static void updateEmployee(Employee emp, EmpService service) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("\n\n=============Update Menu================");
			System.out.println("1. Update name");
			System.out.println("2. Update salary and designation");
			System.out.println("3. Cancel Update");
			System.out.println("Enter choice");

			String choice = br.readLine();

			switch (choice) {
			case "1": // udpate name
				while (true) {
					try {
						String name = generateEName();
						service.updateEmployee(new Employee(emp.getId(), name, emp.getSalary(), emp.getDesg()));
						break;
					} catch (MismatchException e) {
						System.out.println(e.getMessage());
					}
				}
				break;
			case "2":
				while (true) {
					try {
						double sal = generateSalary();
						String desg = generateDesg();
						service.updateEmployee(new Employee(emp.getId(), emp.getName(), sal, desg));
						break;
					} catch (MismatchException e) {
						System.out.println(e.getMessage());
					}
				}
				break;
			case "3":
				return;
			default:
				System.out.println("Invalid choice");

			}
		} catch (IOException e) {
			System.out.println("The ID format is incorrent");
		}
	}

}
