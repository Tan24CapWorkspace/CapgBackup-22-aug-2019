package com.cg.eis.service;

import java.util.Collection;

import com.cg.eis.bean.Order;
import com.cg.eis.dao.OrderRepoImpl;

public class OrderServiceImpl implements OrderService{
	// to access the dao services
	OrderRepoImpl dao = new OrderRepoImpl();
	
	// Calculating price per piece in INR of each item.
	@Override
	public int calculateOrder(Order bean) {
		try {
			// INR is final static variable to hold the dollor to INR value.
			double price = bean.getPrice() * INR; // fetch the price in dallors
			return (int) Math.abs(price);
		}catch(NullPointerException e) {
			System.out.println("Given object is empty");
			return 0;
		}
	}

	// Transfer order object to dao layer after completing all calculations.
	@Override
	public int addOrder(Order bean) {
		int price = calculateOrder(bean);
		bean.setAmount(price * bean.getQuantity());
		bean.setCharges(getCurrencyConversionCharge(bean.getAmount()));
		return dao.saveOrder(bean);
	}

	// To fetch order from dao layer using id
	@Override
	public Order findOrder(int order_id) {
		return dao.findOrder(order_id);
	}

	// To remove order from collection using dao layer
	@Override
	public boolean removeOrder(Order bean) {
		return dao.removeOrder(bean);
	}

	// return the collections of order returned by dao layer
	@Override
	public Collection<Order> getAllOrders() {
		return dao.getAllOrders();
	}
	
	// getCurrencyConversionCharge calculate and return convertion charge on total_amount in INR
	private static double getCurrencyConversionCharge(double amount) {
		return (amount*1.25)/100;
	}
	
	// printOrder for printing orders
	public void printOrder(Order bean) {
		System.out.println("Order id: "+bean.getId());
		System.out.println("Order price: "+bean.getPrice()+" $");
		System.out.println("Order quantity: "+bean.getQuantity());
		System.out.println("Order amount: "+bean.getAmount()+" Rs.");
		System.out.println("Order charges: "+bean.getCharges()+" Rs.");
		System.out.println();
	}
}	
