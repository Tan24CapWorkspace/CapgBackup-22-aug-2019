package com.cg.eis.exception;

public class MismatchException extends Exception{
	public MismatchException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
