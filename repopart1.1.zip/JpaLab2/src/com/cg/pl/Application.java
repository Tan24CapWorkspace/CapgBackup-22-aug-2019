package com.cg.pl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dao.BookAuthorImpl;
import com.cg.entities.Author;
import com.cg.entities.Book;

public class Application {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		
		manager.getTransaction().begin();
		
		
		Author a1 = new Author();
		a1.setID(101);
		a1.setName("James");
		
		Author a2 = new Author();
		a1.setID(102);
		a1.setName("Carter");
		
		manager.persist(a1);
		manager.persist(a2);
		
		List<Author> list1 = new ArrayList<>();
		list1.add(a1);
		
		List<Author> list2 = new ArrayList<>();
		list1.add(a2);
		
		Book b1 = new Book();
		b1.setAuthors(list1);
		b1.setTitle("asdlkjf");
		b1.setPrice(46854D);
		
		Book b2 = new Book();
		b2.setAuthors(list2);
		b2.setTitle("laskjdf");
		b2.setPrice(145D);
		
		manager.persist(b1);
		manager.persist(b2);
		
		manager.getTransaction().commit();
		
		BookAuthorImpl dao = new BookAuthorImpl();
		System.out.println(dao.getAllBooks());
	}
}
