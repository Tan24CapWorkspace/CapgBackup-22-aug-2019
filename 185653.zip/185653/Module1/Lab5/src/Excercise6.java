import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.cg.eis.exception.*;

public class Excercise6 {
	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Enter Employee salary");
			Double salary = Double.parseDouble(br.readLine());
			if(salary < 3000.00) throw new EmployeeException("Salary must be greater than 3000");
			System.out.println("Your salary is : "+salary);
		}catch (IOException e) {
			System.out.println("Wrong input given");
		}catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
