
/**
 *@author tanmpath
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise4 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter a number:");
            int n = Integer.parseInt(br.readLine());
            System.out.println(checkNumber(n) ? "The given number is in power of 2" : "The given number is not in power of 2");
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static boolean checkNumber(int n) {
        int num = n;
        while (true) {
            if (num % 2 == 0) {
                num = num >> 1;
                if (num == 1) {
                    break;
                }
            } else {
                return false;
            }
        }
        return true;
    }

}
