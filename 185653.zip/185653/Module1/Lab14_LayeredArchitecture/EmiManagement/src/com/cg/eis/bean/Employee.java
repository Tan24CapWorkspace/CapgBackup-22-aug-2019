package com.cg.eis.bean;

import java.util.Objects;

/**
 *
 * @author Tanmay Pathak
 */
public class Employee {
    private int id;
    private String name;
    private double salary;
    private String desg;
    private String scheme;

    public Employee() {
    }

    public Employee(int id, String name, double salary, String desg) {
        this.id = id;
        this.name = name.toUpperCase();
        this.salary = salary;
        this.desg = desg.toUpperCase();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name.toUpperCase();
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDesg() {
        return desg;
    }

    public void setDesg(String desg) {
        this.desg = desg.toUpperCase();
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }
    
    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name=" + name + ", salary=" + salary + ", desg=" + desg + ", scheme=" + scheme + '}';
    }

}
