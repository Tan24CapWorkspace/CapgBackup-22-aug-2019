package cg;

import java.util.Comparator;

import com.cg.bean.Account;

public class NameComparator implements Comparator<Account>{

	@Override
	public int compare(Account arg0, Account arg1) {
		return arg0.getAccountholder().compareTo(arg1.getAccountholder());
	}
	
}
