package cg;

import java.util.*;

public class Demo6 {
	public static void main(String[] args) {
		Map<String, Double> m = new HashMap<String, Double>();
		m.put("ram", 5000.00);
		m.put("ravi", 5000.00);
		m.put("kishan", 5000.00);
		m.put("ganesh", 5000.00);
		m.put("ramesh", 5000.00);
		m.put(null, 5000.00);
		System.out.println(m);
		System.out.println(m.size());
		System.out.println(m.get(null));
	}
}
