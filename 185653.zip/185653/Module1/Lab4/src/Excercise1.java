
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author tanmpath
 */
public class Excercise1 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter the number");
            int N = Integer.parseInt(br.readLine());
            if (N >= 0) {
                System.out.println("The sum of cube is : " + sumOfCubes(N));
            } else {
                System.out.println("Number should be positive");
            }
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static int sumOfCubes(int n) {
        int sum = 0;
        while (n > 0) {
            sum += (n % 10) * (n % 10) * (n % 10);
            n = n / 10;
        }
        return sum;
    }
}
