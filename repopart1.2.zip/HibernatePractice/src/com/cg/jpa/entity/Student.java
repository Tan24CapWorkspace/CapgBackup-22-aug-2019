package com.cg.jpa.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "student_meta")
public class Student{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int rollno;
	@Column(length = 20)
	private String name;
	@Column(length = 25)
	private String emailId;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", emailId="
				+ emailId + "]";
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	
}
