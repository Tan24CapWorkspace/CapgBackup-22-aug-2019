package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.print.attribute.ResolutionSyntax;

public class Demo6 implements PrintAccount{
	public static void main(String[] args) throws SQLException {
		Connection con = null;
		PreparedStatement updatest = null;
		PreparedStatement selectst = null;
		try {
			con = DBHelper.getConnection();
			
			// setting auto commit false
			con.setAutoCommit(false);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Enter the account id to delete");
			int id = Integer.parseInt(br.readLine());
			
			updatest = con.prepareStatement("delete from account where aid = ?");
			updatest.setInt(1, id);
			
			selectst = con.prepareStatement("select * from account where aid = ?");
			selectst.setInt(1, id);
			ResultSet rs = selectst.executeQuery();
			
			
			int rowaffected = updatest.executeUpdate();
			
			if(rowaffected != 0) {
				PrintAccount.print(rs);
				System.out.println("Deleted successfully");
			}else {
				System.out.println("No such account exist");
			}
			
			con.commit();
			con.close();
			
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			con.rollback();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(con!=null)con.close();
		}
	}
}
