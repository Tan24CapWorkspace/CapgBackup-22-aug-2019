package com.cg.eis.exception;

// When quantity is less than or equals to 0 then this exception is used
public class QuantityException extends Exception{
	public QuantityException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
