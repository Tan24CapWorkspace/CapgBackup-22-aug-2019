package com.cg.jpa.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.entity.Account;
import com.cg.jpa.entity.Student;

public class JPQLDemo {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		
		
		// adding data to table
		/*Account ac = new Account();
		ac.setAccHolderName("Nikhil");
		ac.setBalance(45000);
		ac.setMobileNo("654564");
		
		Account ac1 = new Account();
		ac1.setAccHolderName("kamal");
		ac1.setBalance(45000);
		ac1.setMobileNo("654564");
		
		Account ac2 = new Account();
		ac2.setAccHolderName("ramesh");
		ac2.setBalance(45000);
		ac2.setMobileNo("654564");
		
		
		Account ac3 = new Account();
		ac3.setAccHolderName("jayesh");
		ac3.setBalance(45000);
		ac3.setMobileNo("654564");
		
		em.getTransaction().begin();
		em.persist(ac);
		em.persist(ac1);
		em.persist(ac2);
		em.persist(ac3);
		em.getTransaction().commit();
		
		System.out.println("Accounts added");*/
		
		// fetching data
		/*
		String query = "select acc from Account acc";
		Query qry = em.createQuery(query);
		List<Account> acclist = qry.getResultList();
		for(Account a : acclist){
			System.out.println(a.toString());
		}
		*/
		
		
		/*
		String query =  "select acc.accHolderName from Account acc";
		TypedQuery<String> qry = em.createQuery(query, String.class);
		List<String> name = qry.getResultList();
		for(String a : name){
			System.out.println(a);
		}
		*/
		
		/*
		String query =  "select max(acc.balance) from Account acc";
		TypedQuery<Double> qry = em.createQuery(query, Double.class);
		Double max = qry.getSingleResult();
		System.out.println(max);
		*/
		
		/*
		String query =  "update Account acc set acc.balance = acc.balance*1.1";
		em.getTransaction().begin();
		Query qry = em.createQuery(query);
		int rows = qry.executeUpdate();
		System.out.println("Rows updated "+rows);
		em.getTransaction().commit();
		*/
		
		/*
		String query =  "select acc.accHolderName from Account acc where acc.balance between :b1 and :b2";
		TypedQuery<String> qry = em.createQuery(query, String.class);
		qry.setParameter("b1", 30000.00);
		qry.setParameter("b2", 50000.00);
		List<String> list = qry.getResultList();
		for(String s : list){
			System.out.println(s);
		}
		*/
		
		/*
		TypedQuery<String> qry = em.createNamedQuery("getNames", String.class);
		qry.setParameter("b1", 30000.00);
		qry.setParameter("b2", 50000.00);
		List<String> list = qry.getResultList();
		for(String s : list){
			System.out.println(s);
		}
		*/
		
		// using named queries
		/*
		em.getTransaction().begin();
		Query qry = em.createNamedQuery("update");
		int rows = qry.executeUpdate();
		System.out.println("Rows updated "+rows);
		em.getTransaction().commit();
		*/
		
		
	}
}
