package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO {
	
	
	private Map<Long,Account> m= new HashMap<Long,Account>();

	@Override
	public boolean addAccount(Account ob) {
		// TODO Auto-generated method stub
		
		m.put(ob.getMobile(),ob);
		return true;
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		
		m.put(ob.getMobile(),ob);
		return true;
	}

	@Override
	public boolean deleteAccount(Account ob) {
		// TODO Auto-generated method stub
		m.remove(ob.getMobile());
		return true;
	}

	@Override
	public boolean transferMoney(Account from, Account to) {
		// TODO Auto-generated method stub
		
		m.put(from.getMobile(), from);
		m.put(to.getMobile(), to);
		return true;
	}

	@Override
	public Account findAccount(long mo) {
		// TODO Auto-generated method stub
		
		return m.get(mo);
	}

	@Override
	public Map<Long, Account> getAllAccount() {
		// TODO Auto-generated method stub
		
		return m;
	}

	



}
