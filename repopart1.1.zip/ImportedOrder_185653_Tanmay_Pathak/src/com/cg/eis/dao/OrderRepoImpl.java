package com.cg.eis.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Order;

public class OrderRepoImpl implements OrderRepo{
	// Map to store orders where key->Order:id and value->Order:object
	Map<Integer, Order> orderList = new HashMap<>();
	
	// Adding order to Collection
	@Override
	public int saveOrder(Order bean) {
		try {
			orderList.put(bean.getId(), bean);
			// return order_id after saving order
			return bean.getId();
		}catch(NullPointerException e) {
			/* return -1 to indicate that order is not saved 
			   because of some exception
			*/
			return -1;
		}
	}

	// findOrder either return Order object or null if object does not present
	@Override
	public Order findOrder(int order_id) {
		return orderList.get(order_id);
	}

	// removeOrder removes the order from collection if present
	@Override
	public boolean removeOrder(Order bean) {
		try {
			orderList.remove(bean.getId());
			return true;
		}catch (NullPointerException e) {
			return false;
		}
	}

	// getAllOrders return collection of orders
	@Override
	public Collection<Order> getAllOrders() {
		return orderList.values();
	}
}
