package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.entities.Author;
import com.cg.entities.Book;

public class BookAuthorImpl implements BookAuthor{

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager = factory.createEntityManager();
	
	@Override
	public List<Book> getAllBooks() {
		Query query = manager.createNamedQuery("getall");
		List<Book> list = query.getResultList();
		return list;
	}

	@Override
	public List<Book> getBooksByAuthorName(Author author) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getBooksBwRange(int min, int max) {
		// TODO Auto-generated method stub
		return null;
	}

}
