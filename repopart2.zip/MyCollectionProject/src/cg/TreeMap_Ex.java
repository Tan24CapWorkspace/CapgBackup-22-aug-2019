package cg;

import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TreeMap_Ex {
	public static void main(String[] args) {
		Map<String, Double> m = new TreeMap<String, Double>();
		m.put("ram", 5000.00);
		m.put("ravi", 5000.00);
		m.put("kishan", 5000.00);
		m.put("ganesh", 5000.00);
		m.put("ramesh", 5000.00);

		// m.put(null, 5000.00);

		System.out.println("Sorted on the basis of the keys");
		System.out.println(m);
		System.out.println("========================================\n");

		// Retrieve keys and printing values
		Set<String> keys = TreeMap_Ex.getKeys(m);
		TreeMap_Ex.printValues(m, keys);
		System.out.println("========================================\n");

		// changing the value of the ram
		Double bal = m.get("ram");
		bal -= 3000.00; // unboxing i.e bal converted to primitive
		m.put("ram", bal); // boxing i.e bal converted to Double object
		System.out.println(m);
		System.out.println("========================================\n");
		
		// sorting the map with respect to values
		sortByValues(m);
	}

	// to get the keys
	public static Set<String> getKeys(Map<String, Double> m) {
		return m.keySet();
	}

	public static void printValues(Map<String, Double> list, Set<String> keys) {
		for (String s : keys) {
			System.out.println(s + " = " + list.get(s));
		}
	}
	
	public static void sortByValues(Map<String, Double> list) {
		/**
		 * list.values() return Collection
		 * new ArrayList<>(Collection object)
		 * Collections to sort the values
		 * The sorting is the inplace sorting
		 * */
		List<Double> valList = new ArrayList<Double>(list.values());
		Collections.sort(valList);
		System.out.println(valList);
		System.out.println("===========================================");
	}
}
