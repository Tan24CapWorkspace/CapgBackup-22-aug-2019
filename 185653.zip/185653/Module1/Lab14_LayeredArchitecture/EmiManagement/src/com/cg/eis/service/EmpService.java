package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAOImpl;
import com.cg.eis.exception.MismatchException;

/**
 *
 * @author Tanmay Pathak
 */
public class EmpService implements EmpServiceInterface{

    EmployeeDAOImpl dao = new EmployeeDAOImpl();
    
    @Override
    public boolean addEmployee(Employee emp) throws MismatchException{
    	 double sal = emp.getSalary();
         String desg = emp.getDesg();
         String scheme = generateScheme(sal, desg);
         emp.setScheme(scheme);
         return dao.addEmployee(emp);
    }

    @Override
    public boolean deleteEmployee(Employee emp) {
        return dao.deleteEmployee(emp);
    }

    @Override
    public boolean updateEmployee(Employee emp) throws MismatchException{
    	double sal = emp.getSalary();
        String desg = emp.getDesg();
        String scheme = generateScheme(sal, desg);
        emp.setScheme(scheme);
        return dao.updateEmployee(emp);
    }

    @Override
    public Employee findEmployee(int id) {
        return dao.findEmployee(id);
    }
    
    
    private String generateScheme(double sal, String desg) throws MismatchException{
        if((sal>=5000.00 && sal<20000.00) && desg.equalsIgnoreCase("System Associate")){
                return "Scheme C";
            }else if((sal>=20000.00 && sal<40000.00) && desg.equalsIgnoreCase("Programmer")){
                return "Scheme B";
            }else if((sal>=40000.00) && desg.equalsIgnoreCase("Manager")){
                return "Scheme A";
            }else if((sal<5000.00) && desg.equalsIgnoreCase("Clerk")){
                return "No Scheme";
            }else{
            	throw new MismatchException("Salary and Desg mismatch\nRe-Enter the information\n");
            }
    }
    
//    private static void printOrder(Order bean) {
//    	System.out.println("Order id : ");
//    }
}
