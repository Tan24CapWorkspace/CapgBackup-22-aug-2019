package com.cg.service;

/**
 * Author: Tanmay Pathak
 * */
import java.util.Map;

import com.cg.bean.Account;
import com.cg.dao.AccountDAOImpl;
import com.cg.exception.InsufficientFundException;

public class AccountService implements Transaction, Gst  { // Alternate to multiple inheritance

	// To link the service and dao layer
	private AccountDAOImpl dao = new AccountDAOImpl();
	
	public double withdraw(Account ob, double amount) throws InsufficientFundException {
		
		double new_balance = ob.getBalance() - amount;
		if (new_balance < 1000.00) {
			new_balance = ob.getBalance();
			throw new InsufficientFundException("Insufficient Fund: Can not process the withdraw", new_balance);
		}
		ob.setBalance(new_balance);
		return new_balance;
	}

	public double deposit(Account ob, double amount) throws InsufficientFundException{
		// TODO Auto-generated method stub
		if(amount < 0.0) throw new InsufficientFundException("Insufficient Fund: Can not process the Deposit", amount);
		double new_balance = ob.getBalance() + amount;
		ob.setBalance(new_balance);
		return new_balance;
	}

	public boolean transferMoney(Account from, Account to, double amount) throws InsufficientFundException{// INCOMPLETE
		// TODO Auto-generated method stub
		double new_balance = from.getBalance() - amount;
		if (!(new_balance < 1000.00)) {
			from.setBalance(new_balance);
			to.setBalance(to.getBalance() + amount);
			return true;
		} else {
			throw new InsufficientFundException("Insufficient Fund: Can not process the transfer", amount);
		}
	}

	public double calculateTax(double PCT, double amount) {
		return amount * Gst.PCT_5;
	}

	public boolean addAccount(Account acc) {
		return dao.addAccount(acc);
	}

	public boolean deleteAccount(Account acc) {
		return dao.deleteAccount(acc);
	}

	public Account findAccount(long mobile) {
		return dao.findAccount(mobile);
	}

	public Map<Long, Account> getAllAccount() {
		return dao.getAccList();
	}

	public boolean updateAccount(Account acc) {
		if(dao.updateAccount(acc) == true) {
			return true;
		}else {
			return false;
		}
	}

	public void printStatement(Account a) {
		
	}
	
}