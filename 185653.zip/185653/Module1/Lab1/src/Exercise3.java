
/**
 *@author tanmpath
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise3 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Enter a number:");
            int n = Integer.parseInt(br.readLine());
            System.out.println(checkNumber(n) ? "The given number is increasing number" : "The given number is not increasing number");
        } catch (IOException e) {
            System.out.println("Wrong input given");
        }
    }

    public static boolean checkNumber(int n) {
        String num = Integer.toString(n);
        for (int i = 0; i < num.length() - 1; i++) {
            if (num.charAt(i) > num.charAt(i + 1)) {
                return false;
            }
        }
        return true;
    }

}
