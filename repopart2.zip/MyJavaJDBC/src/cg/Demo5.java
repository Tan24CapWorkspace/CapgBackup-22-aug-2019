package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo5 implements PrintAccount{
	public static void main(String[] args) throws SQLException {
		Connection con = null;
		PreparedStatement updatest = null;
		PreparedStatement selectst = null;
		try {
			con = DBHelper.getConnection();
			
			// setting auto commit false
			con.setAutoCommit(false);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
//			System.out.println("Enter account id");
//			int id = Integer.parseInt(br.readLine());
//			
//			System.out.println("Enter mobile no");
//			long mobile = Long.parseLong(br.readLine());
			
//			System.out.println("Enter initial balance");
//			double balance = Double.parseDouble(br.readLine());
//			 
//			System.out.println("Enter account holder name");
//			String name = br.readLine();
//			
//			String query = "insert into account values(?,?,?,?)"; 
			
//			PreparedStatement pstm = con.prepareStatement(query);
//			pstm.setInt(1, id);
//			pstm.setLong(2, mobile);
//			pstm.setString(3, name);
//			pstm.setDouble(4, balance);
			
//			int insertedRec = pstm.executeUpdate();
//			
//			System.out.println("Inserted Record : "+insertedRec);
			
			
			System.out.println("Enter account id 1: ");
			int from = Integer.parseInt(br.readLine());
			double frombalance;
			
			System.out.println("Enter account id 2: ");
			int to = Integer.parseInt(br.readLine());
			double tobalance;
			
			System.out.println("Enter the amount to transfer");
			double amount = Double.parseDouble(br.readLine());
			
			selectst = con.prepareStatement("select balance from account where aid = ?");
			selectst.setInt(1, from);
			ResultSet rs = selectst.executeQuery();
			
			if(rs.next()) {
				frombalance = rs.getDouble(1);
				
				selectst.setInt(1, to);
				rs = selectst.executeQuery();
				
				if(rs.next()) {
					tobalance = rs.getDouble(1);
					
					updatest = con.prepareStatement("update account set balance =? where aid = ?");
					updatest.setDouble(1, (frombalance - amount));
					updatest.setInt(2, from);
					updatest.executeUpdate();
					
					updatest.setDouble(1, (tobalance + amount));
					updatest.setInt(2, to);
					updatest.executeUpdate();
					
					System.out.println("Amount transferred");
					
				}else {
					System.out.println("No account with Account id "+to+" is found");
					throw new SQLException();
				}
				
			}else {
				System.out.println("No account with Account id "+from+" is found");
				throw new SQLException();
			}
			
			con.commit();
			con.close();
			
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			con.rollback();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(con!=null)con.close();
		}
	}
}
