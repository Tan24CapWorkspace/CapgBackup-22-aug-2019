package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.service.AccountService;

class AccountServiceTest {
	AccountService service;
	AccountDAO mockdao;
	
	
	@BeforeEach
	public void setup() {
		service = new AccountService();
		mockdao = EasyMock.createMock(AccountDAO.class);
		service.setAccountDAOImpl(mockdao);
	}
	
	@Test
	public void testFind(){
		long mobile = 1234567895;
		
		Account account = new Account(101, 1234567895, "Krish", 25000);
		
		EasyMock.expect(mockdao.findAccount(mobile)).andReturn(account);
		
		EasyMock.replay(mockdao);
		
		assertEquals(account, service.findAccount(mobile));
		
		EasyMock.verify(mockdao);
	}
}
