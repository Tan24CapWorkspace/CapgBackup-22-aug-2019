package cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ValidatorTest {
	
	@Test
	void test1() {
		Validator ob = new Validator();
		assertTrue(ob.validator("100"));
		assertFalse(ob.validator("acgv"));
	}
	
	@Test
	void test2() {
		Validator ob = new Validator();
		assertThrows(NullPointerException.class, ()->ob.validator(null));
	}
	
	
}
