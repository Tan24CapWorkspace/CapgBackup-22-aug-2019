package com.cg;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Demo2 {
	public static void main(String[] args) {
		/*
		 * Runnable interface using lambda
		 * */
		Executor executor = Executors.newSingleThreadExecutor();
		Runnable task = ()->System.out.println("Happy birthday DON "+Thread.currentThread().getName());
		executor.execute(task);
	}
}
