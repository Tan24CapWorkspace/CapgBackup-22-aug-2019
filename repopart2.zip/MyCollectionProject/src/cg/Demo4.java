package cg;

import java.util.TreeSet;
import java.util.Set;

public class Demo4 {
	public static void main(String[] args) {
		Set<String> col = new TreeSet<String>();
		/**
		 * TreeSet does not main the insertion order
		 * Give the elements in sorted form.
		 * */
		col.add("ram");
		col.add("shayam");
		col.add("abdul");
		col.add("55");
		// col.add(null);
		/**
		 * TreeSet does not accept the NULL;
		 * Exception in thread "main" java.lang.NullPointerException at
		 * java.util.TreeMap.put(Unknown Source) at java.util.TreeSet.add(Unknown
		 * Source) at cg.Demo4.main(Demo4.java:13)
		 * 
		 */
		col.add("ganesh");
		col.add("ram");
		System.out.println(col);
	}
}
