package cg;

import java.util.Set;
import java.util.HashSet;

public class Demo1 {
	public static void main(String[] args) {
		/**
		 * Multiple markers at this line - HashSet is a raw type. References to generic
		 * type HashSet<E> should be parameterized - Set is a raw type. References to
		 * generic type Set<E> should be parameterized
		 */
		Set col = new HashSet();
		/**
		 * This is the NOT-Generic collection set.
		 */
		col.add("ram");
		col.add("shayam");
		col.add("abdul");
		col.add(55);
		col.add(null);
		col.add("ganesh");
		col.add("ram");
		System.out.println(col);

	}
}
