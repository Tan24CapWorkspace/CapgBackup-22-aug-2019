package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Iterator;

import com.cg.eis.bean.Order;
import com.cg.eis.exception.QuantityException;
import com.cg.eis.service.OrderServiceImpl;
import com.cg.eis.service.Validator;

public class UserInterfaceImpl {
	// To take input from user
	private static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	// To communicate with service layer
	private static OrderServiceImpl service = new OrderServiceImpl();

	public static void main(String[] args) {
		while (true) {
			try {
				System.out.println("\n\n=============================MENU=========================");
				System.out.println("1. Add New Order");
				System.out.println("2. Find Order");
				System.out.println("3. Remove Order");
				System.out.println("4. Print All Orders");
				System.out.println("5. EXIT");
				System.out.println("Enter your Choice");
				String choice = br.readLine();

				switch (choice) {
				case "1": // for adding orders
					Order order = generateOrder();
					if (service.addOrder(order) != -1) {
						System.out.println("Order ");
						service.printOrder(order);
						System.out.println("successfully added");
					} else {
						System.out.println("Order not added");
					}
					break;
				
				case "2": // for finding order
					System.out.println("Enter order_id");
					String order_id = br.readLine();
					order = service.findOrder(Integer.parseInt(order_id));
					if (order != null) {
						System.out.println("Order found");
						service.printOrder(order);
					} else {
						System.out.println("No order with order_id : " + order_id + " found.");
					}
					break;
				
				case "3": // for removing orders
					System.out.println("Enter order_id");
					order_id = br.readLine();
					order = service.findOrder(Integer.parseInt(order_id));
					if (order != null) {
						service.removeOrder(order);
						System.out.println("Order");
						service.printOrder(order);
						System.out.println("Removed successfully.");
					} else {
						System.out.println("No order with order_id : " + order_id + " found.");
					}
					break;
				
				case "4": // for printing orders
					Collection<Order> order_list = service.getAllOrders();
					Iterator<Order> iterator = order_list.iterator();
					while(iterator.hasNext()) {
						service.printOrder(iterator.next());
					}
					break;
				
				case "5": // for EXIT
					System.exit(0);
					break;
				
				default:
					System.out.println("Wrong choice given\nRe-Enter your choice");
				}
			} catch (IOException e) {
				System.out.println("Wrong input given");
			}
		}
	}

	/*
	 * private method to get inputs from user and after validating return Order
	 * object to main method of pl.
	 */
	private static Order generateOrder() {
		try {
			int order_id = generateOrderId();
			System.out.println("Enter details for order_id : " + order_id);
			double price = getOrderPrice();
			int quantity = getOrderQuantity();
			Order order = new Order();
			order.setId(order_id);
			order.setPrice(price);
			order.setQuantity(quantity);
			return order;
		} catch (Exception e) {
			return null;
		}
	}

	// generateOrderId generate order_id using using Math.random()
	// which is not present in collection
	private static int generateOrderId() {
		while (true) {
			int order_id = (int) Math.abs(Math.random() * 10000);
			if (service.findOrder(order_id) == null)
				return order_id;
		}
	}

	// getOrderPrice get the price from user after validating it.
	private static double getOrderPrice() {
		while (true) {
			try {
				System.out.println("Enter price of each Item (in Dollars)");
				String price = br.readLine();
				// Validator is an interface in com.cg.eis.service having regex to validate price.
				if (Validator.validateData(price, Validator.price_pattern)) {
					return Double.parseDouble(price);
				} else {
					System.out.println("Price must be positive and greater than 0");
				}
			} catch (IOException e) {
				System.out.println("Wrong input given");
			}
		}
	}

	// getOrderQuantity get the quantity from user after validating it.
	private static int getOrderQuantity() {
		while (true) {
			try {
				System.out.println("Enter quantity of Item");
				String quantity = br.readLine();
				// Validator is an interface in com.cg.eis.service having regex to validate quantity.
				if (Validator.validateData(quantity, Validator.quantity_pattern)) {
					int quan = Integer.parseInt(quantity);
					if (quan <= 0) {  // raising custom QuantityException when quantity <= 0.
						throw new QuantityException("Quantity must be greater than 0");
					}
					return quan;
				} else {
					System.out.println("Quantity must be numeric.");
				}
			} catch (IOException e) {
				System.out.println("Wrong input given");
			} catch (QuantityException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
